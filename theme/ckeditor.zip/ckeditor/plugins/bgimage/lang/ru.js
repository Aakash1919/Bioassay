
CKEDITOR.plugins.setLang('bgimage','ru',{
	bgImageTitle : 'Фоновое изображение',
	imageUrl     : 'URL изображения',
	repeat	     : 'Повторение',
	attachment   : 'Привязка',
	blendMode    : 'Режим наложения',
	position     : 'Позиция',
	bgWidth      : 'Ширина (CSS unit, напр. 20px)',
	bgHeight     : 'Высота (CSS unit, напр. 20%)'
})
